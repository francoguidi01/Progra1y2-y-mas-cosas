#include "productos.h"

stProducto cargarUnProducto ()
{
    stProducto a;

//        printf("\nIngrese nombre del producto: ");
//        fflush(stdin);
//        gets(a.nombre);
//        printf("\nIngrese la marca del producto: ");
//        fflush(stdin);
//        gets(a.marca);
        printf("\nIngrese el precio del producto: ");
        scanf("%f", &a.precio);
//        printf("\nEl producto se encuentra eliminado? 1/0: ");
//        scanf("%d", &a.eliminado);
    return a;
}
void mostrarMuchosProducto(stProducto a)
{
    int i=0
    while (i<validos)
    {
        mostrarUnProducto(a);
        i++;
    }
}

void mostrarUnProducto(stProducto a)
{
    puts("\n---------------");
    printf("\n ID del producto: %d",a.idProducto);
    printf("\n Nombre del producto: %s",a.nombreProducto);
    printf("\n Descripcion: %s",a.descripcionProducto);
    printf("\n El precio del producto: %0.02f", a.precio);
    printf("\n Quedan: %d", a.cantidad);
    estadoDelProducto(a.productoAnulado);
    puts("\n---------------");
}


void estadoDelProducto(int numero)
{
    if (numero==1)
    {
        printf("\n El producto se no encuentra eliminado: %d", numero);
    }
    else if (numero==0)
    {
        printf("\n El producto  se encuentra eliminado: %d", numero);
    }
    else
    {
        printf("\n ERROR: %d", numero);
    }
}
int contarProductos(char archivoProductos[])
{
    int cantidad=0;

    FILE*productos;

    productos=fopen(archivoProductos,"rb");

    if(productos!=NULL)
    {
        fseek(productos,0,SEEK_END);

        cantidad= ftell(productos)/sizeof(stProducto);
        fclose(productos);
    }
    return cantidad;
}

int deArchivoToArrayProductos (stProducto prods[], char archivo [])
{
    FILE * produtos=fopen(archivo,"rb");
    stProducto aux;
    int i=0;

    if (produtos)
    {
        while(fread(&aux,sizeof(stProducto),1,produtos)>0)
        {
            prods[i]=aux;
            i++;
        }
    }
    fclose(produtos);
    return i;
}
void agregarDeArrayAArchivo(char archivoAPasar[], stProducto prods)
{
    FILE * archi=fopen(archivoAPasar,"ab");
    if (archi!=NULL)
    {
        fwrite(&prods,sizeof(stProducto),1,archi);
    }
    fclose(archi);
}
void deArrayAArchivo(char archivoAPasar[], stProducto prods[], int validos)
{
    FILE * archi=fopen(archivoAPasar,"wb");

    int i=0;
    if (archi!=NULL)
    {
        while (i<validos)
        {
            fwrite(&prods[i],sizeof(stProducto),1,archi);
            i++;
        }
    }
    fclose(archi);
}
