#ifndef PRODUCTOS_H_INCLUDED
#define PRODUCTOS_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <time.h>
#include <wchar.h>
#include <locale.h>
#include <windows.h>

typedef struct
{
    int idProducto;
    char nombreProducto [30];
    char descripcionProducto [140];
    float valor;
    int cantidad;
    int productoAnulado;
} stProducto;

stProducto cargarUnProducto ();
void mostrarMuchosProducto(stProducto a);
void mostrarUnProducto(stProducto a);
void estadoDelProducto(int numero);
int contarProductos(char archivoProductos[]);
int deArchivoToArrayProductos (stProducto prods[], char archivo []);
void deArrayAArchivo(char archivoAPasar[], stProducto prods[], int validos);
void agregarDeArrayAArchivo(char archivoAPasar[], stProducto prods);

#endif // PRODUCTOS_H_INCLUDED
