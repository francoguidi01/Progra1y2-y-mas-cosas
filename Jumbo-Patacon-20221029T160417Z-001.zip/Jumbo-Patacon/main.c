#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <time.h>
#include <wchar.h>      /// Incluye un soporte para amplios tipos de caracteres.
#include <locale.h>     /// Incluye el soporte para distintos tipos de formatos de fecha, moneda, texto, etc.
#include <windows.h>

#include "menu.h"
#include "ADL.h"
#include "listaProductos.h"
#include "productos.h"

int main()
{
    printf("Hello world!\n");
    return 0;
}
