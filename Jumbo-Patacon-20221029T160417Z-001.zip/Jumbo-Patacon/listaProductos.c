#include "listaProductos.h"

nodoListaProducto * inicListaProducto()
{
    return NULL;
}
nodoListaProducto * crearNodoListaProducto(stProducto p)
{
    nodoListaProducto *aux = (nodoListaProducto *) malloc(sizeof(nodoListaProducto));
    aux ->p = p;
    aux ->siguiente =NULL;
    return aux;
}
nodoListaProducto * agregarAlPrincipioProducto(nodoListaProducto * lista, nodoListaProducto * nuevoNodo)
{
    if (lista == NULL)
    {
        lista = nuevoNodo;
    }
    else
    {
        nuevoNodo->siguiente = lista;
    }
        lista = nuevoNodo;
    return lista;
}
nodoListaProducto * agregarAlFinalProducto(nodoListaProducto * lista, nodoListaProducto * nuevo)
{
    if(lista== NULL)
    {
        lista=nuevo;
    }
    else
    {
        nodoListaProducto * ultimo = inicListaProducto();
        ultimo=buscarUltimoNodoProducto(lista);
        ultimo->siguiente=nuevo;
    }return lista;
}
nodoListaProducto * buscarUltimoNodoProducto(nodoListaProducto * lista)
{
	nodoListaProducto * ultimo=lista;
	if(ultimo!=NULL){
	while(ultimo->siguiente != NULL)
	{
		ultimo=ultimo->siguiente;
	}
	}return ultimo;
}
nodoListaProducto * agregarEnOrdenPorNombreProducto(nodoListaProducto * lista, nodoListaProducto * nuevo)
{

	if(lista==NULL)
	{
		lista=nuevo;
	}
	else
	{
	    if(strcmp(nuevo->p.nombreProducto,lista->p.nombreProducto)<0)
	    {
	        lista=agregarAlPrincipioProducto(lista,nuevo);
	    }
	    else
        {
            nodoListaProducto * ante=lista;
            nodoListaProducto * sig=lista->siguiente;
            while(sig!=NULL && strcmp(sig->p.nombreProducto,nuevo->p.nombreProducto)<0)
            {
                ante=sig;
                sig=sig->siguiente;
            }
            ante->siguiente=nuevo;
            nuevo->siguiente=sig;
        }
	}
return lista;
}
void mostrarListaRecursivaProductos(nodoListaProducto * lista)
{
    if(lista!=NULL)
    {
        mostrarUnProducto(lista->p);
        mostrarListaRecursivaProductos(lista->siguiente);
    }
}
nodoListaProducto * borrarNodoPorIdProducto(nodoListaProducto * lista, int id)
{
    nodoListaProducto * seg=lista;
    nodoListaProducto * ante;
    while((seg!=NULL)&& (lista->p.idProducto!=id))
    {
        ante=seg;
        seg=seg->siguiente;
    }
    if(seg!=NULL)
    {
        ante->siguiente=seg->siguiente;
        free(seg);
    }return lista;
}

nodoListaProducto * borrarTodaLaListaProducto(nodoListaProducto * lista)
{
    nodoListaProducto * actual=lista;

    while (lista!=NULL)
    {
        actual=lista;
        lista=lista->siguiente;
        free(actual);
    }
    return lista;
}
void copiarProdArbolLista(nodoArbol * arbol, nodoListaProducto ** lista, stProducto dato)
{
    nodoArbol * aux;
    stProducto p;
    if(arbol!=NULL)
    {
        aux=buscar(arbol,dato);
        if(aux!=NULL)
        {
            p =retornaProdNodo(aux);
            (*lista)=agregarAlPrincipioProducto((*lista),crearNodoListaProducto(p));
        }
    }
}
