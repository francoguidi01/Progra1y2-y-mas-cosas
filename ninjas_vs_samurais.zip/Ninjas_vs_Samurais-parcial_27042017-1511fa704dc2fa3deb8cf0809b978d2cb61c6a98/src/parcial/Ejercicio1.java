/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial;

import solucion.Katana;

/**
 * Probar la clase Katana
 * a) getHojaMitica() debe retornar el valor correcto
 * b) getDaño() si es una hoja mitica debe retornar 20 * 1.5 * modFiloExtremo
 * c) getDaño() si no es una hoja mitica debe retornar 20 * modeFiloExtremo
 *
 * @author edwin
 */
public class Ejercicio1 implements Evaluable {

    @Override
    public boolean esCorrecto() {
        boolean a, b, c;
        a = a();
        b = b();
        c = c();
        return a && b && c;
    }

    public boolean a() {
        String mensaje = "1a) incorrecto";
        Katana k = new Katana(true, 1.0);
        boolean correcto = k.getEsHojaMitica();
        if (correcto) {
            mensaje = "1a) correcto";
        }
        p.println(mensaje);
        return correcto;
    }

    public boolean b() {
        String mensaje = "1b) incorrecto";
        Katana k = new Katana(true, 2.0);
        Integer daño = (int) (20 * 1.5 * 2.0);
        boolean correcto = k.getEsHojaMitica() && k.getDaño().equals(daño);
        if (correcto) {
            mensaje = "1b) correcto";
        }
        p.println(mensaje);
        return correcto;
    }

    public boolean c() {
        String mensaje = "1c) incorrecto";
        Katana k = new Katana(false, 3.0);
        Integer daño = (int) (20 * 3.0);
        boolean correcto = !k.getEsHojaMitica() && k.getDaño().equals(daño);
        if (correcto) {
            mensaje = "1c) correcto";
        }
        p.println(mensaje);
        return correcto;
    }

    @Override
    public String toString() {
        return "Ejercicio 1";
    }
}
