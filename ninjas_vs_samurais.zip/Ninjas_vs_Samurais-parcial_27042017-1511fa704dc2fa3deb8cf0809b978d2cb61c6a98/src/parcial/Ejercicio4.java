package parcial;

import solucion.Guerrero;
import solucion.Ninja;
import solucion.Shuriken;

/**
 * Probar la clase Ninja
 * a) atacar(k:Shuriken): si k tiene modPuntasVenenosas es 8.5 debe retornar 2*8.5*(random entre 0 y 1)
 * b) defender() y serGolpeado(): si recibe 50 puntos de daño y tiene reflejos sobrenaturales, getSalud() debe retornar 51
 * c) defender() y serGolpeado(): si recibe 50 puntos de daño y no tiene reflejos sobrenaturales, getSalud() debe retornar 50
 * Created by edwin on 28/04/17.
 */
public class Ejercicio4 implements Evaluable {

    @Override
    public boolean esCorrecto() {
        boolean a, b, c;
        a = a();
        b = b();
        c = c();
        return a && b && c;
    }

    @Override
    public String toString() {
        return "Ejercicio 4";
    }

    public boolean a() {
        Guerrero g = new Ninja(false, new Shuriken(2.0));
        Integer dañoMaximo = (int) (2 * 8.5);
        Integer dañoAtaque = g.atacar();
        String mensaje = "";
        boolean correcto = 0 <= dañoAtaque && dañoAtaque <= dañoMaximo;
        mensaje = correcto ? "4a) correcto" : "4a) incorrecto";
        p.println(mensaje);
        return correcto;
    }

    public boolean b() {
        Guerrero g = new Ninja(true, new Shuriken(2.0));
        g.serGolpeado(50);
        String mensaje = "";
        boolean correcto = g.getSalud() == 51;
        mensaje = correcto ? "4b) correcto" : "4b) incorrecto";
        p.println(mensaje);
        return correcto;
    }

    public boolean c() {
        Guerrero g = new Ninja(false, new Shuriken(2.0));
        g.serGolpeado(50);
        String mensaje = "";
        boolean correcto = g.getSalud() == 50;
        mensaje = correcto ? "4c) correcto" : "4c) incorrecto";
        p.println(mensaje);
        return correcto;
    }
}
