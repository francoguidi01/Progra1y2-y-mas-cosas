package parcial;

import solucion.Guerrero;
import solucion.Katana;
import solucion.Samurai;
import solucion.SamuraisOda;

import java.util.ArrayList;

/**
 * Probar la clase SamuraisOda
 * a) quitarElPrimeroDeLaFila() tiene que devolver el primer elemento del Deque
 * b) ponerEnLaFila(g:Guerrero) tiene que insertar el guerrero al final de la fila
 * c) quedanGuerreros() tiene que devolver false si no hay guerreros en la fila
 * Created by edwin on 28/04/17.
 */
public class Ejercicio5 implements Evaluable {
    private ArrayList<Guerrero> guerreros;

    {
        guerreros = new ArrayList<Guerrero>();
        guerreros.add(new Samurai(false, new Katana(true, 2.0)));
        guerreros.add(new Samurai(false, new Katana(true, 2.0)));
        guerreros.add(new Samurai(false, new Katana(true, 2.0)));
    }

    @Override
    public boolean esCorrecto() {
        boolean a, b, c;
        a = a();
        b = b();
        c = c();
        return a && b && c;
    }

    @Override
    public String toString() {
        return "Ejercicio 5";
    }

    public boolean a() {
        SamuraisOda s = new SamuraisOda(guerreros);
        Guerrero peek = s.getSamurais().peekFirst();
        Guerrero pop = s.quitarElPrimeroDeLaFila();
        String mensaje = "";
        boolean correcto = peek == pop;
        mensaje = correcto ? "5a) correcto" : "5a) incorrecto";
        p.println(mensaje);
        return correcto;
    }

    public boolean b() {
        SamuraisOda s = new SamuraisOda(guerreros);
        Guerrero nuevo = new Samurai(false, new Katana(true, 2.0));
        s.ponerEnLaFila(nuevo);
        Guerrero peek = s.getSamurais().peekLast();
        String mensaje = "";
        boolean correcto = nuevo == peek;
        mensaje = correcto ? "5b) correcto" : "5b) incorrecto";
        p.println(mensaje);
        return correcto;
    }

    public boolean c() {
        SamuraisOda s = new SamuraisOda(new ArrayList<Guerrero>());
        String mensaje = "";
        boolean correcto = true;
        mensaje = correcto ? "5c) correcto" : "5c) incorrecto";
        p.println(mensaje);
        return correcto;
    }
}
