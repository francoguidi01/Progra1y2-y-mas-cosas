/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial;

import java.io.PrintStream;
import java.util.ArrayList;

/**
 * @author edwin
 */
public class Parcial {

    public static void main(String[] args) {

        ArrayList<Evaluable> ejercicios = new ArrayList<Evaluable>();

        PrintStream p = System.out;
        String mensaje = "";

        //ejercicios.add(new Ejercicio1());
        //ejercicios.add(new Ejercicio2());
        //ejercicios.add(new Ejercicio3());
        //ejercicios.add(new Ejercicio4());
        //ejercicios.add(new Ejercicio5());
        //ejercicios.add(new Ejercicio6());
        //ejercicios.add(new Ejercicio7());

        if(ejercicios.size() == 0){
            p.println("Hay que descomentar los ejercicios para que se ejecuten");
        }
        for (Evaluable e : ejercicios) {
            mensaje = e.esCorrecto() ? e + " correcto" : e + " incorrecto";
            p.println(mensaje);
        }
    }
}
