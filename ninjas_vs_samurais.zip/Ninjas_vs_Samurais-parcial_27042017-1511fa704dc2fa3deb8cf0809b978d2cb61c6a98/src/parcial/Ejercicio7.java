package parcial;

import solucion.*;

import java.util.ArrayList;

/**
 * Probar la clase SimuladorDeBatalla
 * a) crearSamuraisOda() tiene que devolver un array que contenga 100 samurais que tengan armadura mítica y otros que no.
 * b) crearRebeldesIga() tiene que devolver un array que contenga 100 ninjas que tengan reflejos sobrenaturales y otros que no.
 * c) simularCombate(n:ninja, s:samurai) tiene que realizar "samurai ataca ninja" y el ninja recibe el golpe.
 * Luego se debe realizar "ninja ataca samurai" y el samurai recibe el golpe. Ámbos hayan sido heridos.
 * d) simularBatalla() mientras hayan samurais se tienen que simular combates entre el primero del ejército Oda
 * y el primero del ejército Iga. Si sobreviven (salud != 0) deben ser reincorporados a su ejércitos. Si en algún
 * momento todos los ninjas mueren hay que crear más. Hay que llevar la cuenta de cuántos ninjas mueren antes
 * de que todos  los samurais mueran. Si las clases y sus método están bien implementadas el numero de ninjas muertos
 * oscila entre 165 y 230.
 * Created by edwin on 28/04/17.
 */
public class Ejercicio7 implements Evaluable {
    SimuladorDeBatalla simulador;

    {
        System.out.println("\n\nInicializando ejercicio 7");
        simulador = new SimuladorDeBatalla();
        System.out.println("Ejercicio 7 inicializado \n\n");
    }

    @Override
    public boolean esCorrecto() {
        boolean a, b, c, d;
        a = a();
        b = b();
        c = c();
        d = d();
        return a && b && c && d;
    }

    @Override
    public String toString() {
        return "Ejercicio 7";
    }

    private boolean a() {
        ArrayList<Guerrero> guerreros = simulador.crearSamuraisOda();
        boolean correcto = false, mitico = false, noMitico = false, noHayNinjas = true;
        for (Guerrero g : guerreros) {
            if (!(g instanceof Samurai)) {
                noHayNinjas = false;
                break;
            }
            if (!noMitico && !((Samurai) g).getTieneArmaduraMitica()) {
                noMitico = true;
            }
            if (!mitico && ((Samurai) g).getTieneArmaduraMitica()) {
                mitico = true;
            }
        }
        correcto = noHayNinjas && mitico && noMitico && guerreros.size() == 100;
        String mensaje = correcto ? "7a) correcto" : "7a) incorrecto";
        p.println(mensaje);
        return correcto;
    }

    private boolean b() {
        ArrayList<Guerrero> guerreros = simulador.crearRebeldesIga();
        boolean correcto = false, conReflejos = false, sinReflejos = false, noHaySamurais = true;
        for (Guerrero g : guerreros) {
            if (!(g instanceof Ninja)) {
                noHaySamurais = false;
                break;
            }
            if (!sinReflejos && !((Ninja) g).getTieneReflejosSobrenaturales()) {
                sinReflejos = true;
            }
            if (!conReflejos && ((Ninja) g).getTieneReflejosSobrenaturales()) {
                conReflejos = true;
            }
        }
        correcto = noHaySamurais && conReflejos && sinReflejos && guerreros.size() == 100;
        String mensaje = correcto ? "7b) correcto" : "7b) incorrecto";
        p.println(mensaje);
        return correcto;
    }

    private boolean c() {
        Ninja n = new Ninja(false, new Shuriken(1.0));
        Samurai s = new Samurai(false, new Katana(false, 1.0));
        simulador.simularCombate(n, s);
        boolean correcto = n.getSalud() < 100 && s.getSalud() < 80;
        String mensaje = correcto ? "7c) correcto" : "7c) incorrecto";
        p.println(mensaje);
        return correcto;
    }

    private boolean d() {
        simulador.simularBatalla();
        boolean correcto = !simulador.getEjercitoOda().quedanGuerreros() && simulador.getNinjasMuertos() > 165 && simulador.getNinjasMuertos() < 230;
        String mensaje = correcto ? "7d) correcto" : "7d) incorrecto";
        p.println(mensaje);
        return correcto;
    }
}
