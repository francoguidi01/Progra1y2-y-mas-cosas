package parcial;

import solucion.Guerrero;
import solucion.Ninja;
import solucion.RebeldesIga;
import solucion.Shuriken;

import java.util.ArrayList;

/**
 * Probar la clase RebeldesIga
 * a) quitarElPrimeroDeLaFila() tiene que devolver el primer elemento del Stack
 * b) ponerEnLaFila(g:Guerrero) tiene que insertar el guerrero al tope del Stack
 * c) quedanGuerreros() tiene que devolver false si no hay guerreros en el Stack
 * Created by edwin on 28/04/17.
 */
public class Ejercicio6 implements Evaluable {
    private ArrayList<Guerrero> guerreros;

    {
        guerreros = new ArrayList<Guerrero>();
        guerreros.add(new Ninja(true, new Shuriken(2.0)));
        guerreros.add(new Ninja(true, new Shuriken(2.0)));
        guerreros.add(new Ninja(true, new Shuriken(2.0)));
    }

    @Override
    public boolean esCorrecto() {
        boolean a, b, c;
        a = a();
        b = b();
        c = c();
        return a && b && c;
    }

    @Override
    public String toString() {
        return "Ejercicio 5";
    }

    public boolean a() {
        RebeldesIga s = new RebeldesIga(guerreros);
        Guerrero peek = s.getNinjas().peek();
        Guerrero pop = s.quitarElPrimeroDeLaFila();
        String mensaje = "";
        boolean correcto = peek == pop;
        mensaje = correcto ? "6a) correcto" : "6a) incorrecto";
        p.println(mensaje);
        return correcto;
    }

    public boolean b() {
        RebeldesIga s = new RebeldesIga(guerreros);
        Guerrero nuevo = new Ninja(true, new Shuriken(2.0));
        s.ponerEnLaFila(nuevo);
        Guerrero peek = s.getNinjas().peek();
        String mensaje = "";
        boolean correcto = nuevo == peek;
        mensaje = correcto ? "6b) correcto" : "6b) incorrecto";
        p.println(mensaje);
        return correcto;
    }

    public boolean c() {
        RebeldesIga s = new RebeldesIga(new ArrayList<Guerrero>());
        String mensaje = "";
        boolean correcto = true;
        mensaje = correcto ? "6c) correcto" : "6c) incorrecto";
        p.println(mensaje);
        return correcto;
    }
}
