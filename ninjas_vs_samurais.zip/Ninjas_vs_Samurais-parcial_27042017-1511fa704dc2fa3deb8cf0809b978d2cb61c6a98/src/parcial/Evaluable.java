package parcial;

import java.io.PrintStream;

/**
 * Created by edwin on 28/04/17.
 */
public interface Evaluable {
    public static PrintStream p = System.out;

    public boolean esCorrecto();
}
