package parcial;

import solucion.Guerrero;
import solucion.Katana;
import solucion.Samurai;

/**
 * Probar la clase Samurai
 * a) atacar(k:Katana): si k es mitica y el modFiloExtremo es 2.0 debe retornar 20*1.5*2*(random entre 0 y 1)
 * b) defender() y serGolpeado(): si recibe 20 puntos de daño y tiene armadura mitica, getSalud() debe retornar 78
 * c) defender() y serGolpeado(): si recibe 20 puntos de daño y no tiene armadura mitica, getSalud() debe retornar 66
 * Created by edwin on 28/04/17.
 */
public class Ejercicio3 implements Evaluable {
    @Override
    public boolean esCorrecto() {
        boolean a, b, c;
        a = a();
        b = b();
        c = c();
        return a && b && c;
    }

    @Override
    public String toString() {
        return "Ejercicio 3";
    }

    public boolean a() {
        Guerrero g = new Samurai(false, new Katana(true, 2.0));
        Integer dañoMaximo = (int) (20 * 1.5 * 2.0);
        Integer dañoAtaque = g.atacar();
        String mensaje = "";
        boolean correcto = 0 <= dañoAtaque && dañoAtaque <= dañoMaximo;
        mensaje = correcto ? "3a) correcto" : "3a) incorrecto";
        p.println(mensaje);
        return correcto;
    }

    public boolean b() {
        Guerrero g = new Samurai(true, new Katana(true, 2.0));
        g.serGolpeado(20);
        String mensaje = "";
        boolean correcto = g.getSalud() == 78;
        mensaje = correcto ? "3b) correcto" : "3b) incorrecto";
        p.println(mensaje);
        return correcto;
    }

    public boolean c() {
        Guerrero g = new Samurai(false, new Katana(true, 2.0));
        g.serGolpeado(20);
        String mensaje = "";
        boolean correcto = g.getSalud() == 66;
        mensaje = correcto ? "3c) correcto" : "3c) incorrecto";
        p.println(mensaje);
        return correcto;
    }
}
