package parcial;

import solucion.Arma;
import solucion.Shuriken;

/**
 * Probar la clase Shuriken
 * a) getDaño() debe retornar 2 * modPuntasVenenosas
 *
 * @author edwin
 */
public class Ejercicio2 implements Evaluable {
    @Override
    public boolean esCorrecto() {
        boolean a;
        a = a();
        return a;
    }

    public boolean a() {
        String mensaje = "2a) incorrecto";
        Arma k = new Shuriken(5.0);
        Integer daño = (int) (2 * 5.0);
        boolean correcto = k.getDaño().equals(daño);
        if (correcto) {
            mensaje = "2a) correcto";
        }
        p.println(mensaje);
        return correcto;
    }

    @Override
    public String toString() {
        return "Ejercicio 2";
    }
}
