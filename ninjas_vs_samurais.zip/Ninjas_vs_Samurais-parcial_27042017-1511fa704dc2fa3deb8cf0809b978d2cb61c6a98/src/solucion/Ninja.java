package solucion;

class Ninja{
}
