package solucion;

class Arma {
}
