package solucion;

import java.util.ArrayList;
import java.util.Stack;

class RebeldesIga{
}
