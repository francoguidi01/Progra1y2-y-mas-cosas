package solucion;

class Samurai{
}
