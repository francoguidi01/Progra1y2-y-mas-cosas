package solucion;

class Shuriken{
}
