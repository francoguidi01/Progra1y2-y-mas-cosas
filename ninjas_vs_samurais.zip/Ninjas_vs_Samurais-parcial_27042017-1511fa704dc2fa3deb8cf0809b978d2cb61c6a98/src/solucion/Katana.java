
package solucion;

public class Katana extends Arma {
}
