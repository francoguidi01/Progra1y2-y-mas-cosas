#include "listaPedidos.h"



stPedido cargarPedido(stPedido p, int idCliente, int idPedido)
{
    system("cls");
    puts("\n\t>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>-Realizar pedido-<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");


    printf("\n\t\t\t Id Pedido: %d", idPedido+1);
    p.idPedido=idPedido+1;


    printf("\n\t\t\t Id Cliente: %d\n", idCliente);
    p.idCliente=idCliente;

    return p;
}

int cantidadPedidos()
{
    stPedido p;
    FILE *archPedido= fopen("pedidos.dat","rb");
    int cantidadPedidos=0;

    if(archPedido!=NULL)
    {
        while(fread(&p, sizeof(stPedido), 1, archPedido))
        {
            cantidadPedidos++;
        }
    }
    fclose(archPedido);
    return cantidadPedidos;
}

void buscarPedido()
{
    FILE * archiP = NULL;
    int idPed;
    printf("\n-----------------Buscar Pedido-------------------\n");
    printf("\n Ingresa el Id de pedido para buscar: ");
    scanf("%d", &idPed);

    archiP=fopen("pedidos.dat","rb");
    fseek(archiP,0,SEEK_SET);
    stPedido p;

    if(archiP!=NULL)
    {
        while(fread(&p,sizeof(stPedido),1,archiP))
        {
            if(idPed==p.idPedido)
            {
                mostrarStructPedido(p);
                system("pause");
            }
        }
    }
    fclose(archiP);
}

void buscarPedidoCliente(int idCliente)
{
    FILE * archiP = NULL;
    int idPed;
    printf("\n-----------------Buscar Pedido-------------------\n");
    printf("\n Ingresa el Id de pedido para buscar: ");
    scanf("%d", &idPed);

    archiP=fopen("pedidos.dat","rb");

    stPedido p;

    if(archiP!=NULL)
    {
        while(fread(&p,sizeof(stPedido),1,archiP))
        {
            if(idPed==p.idPedido)
            {
                if(idCliente==p.idCliente)
                {
                    mostrarStructPedido(p);
                }
                else
                {
                    printf("\nEl pedido no fue encontrado\n\n");
                }
            }
        }
    }
    fclose(archiP);
}

void archAltaPedido(stPedido p, int idCliente)
{
    FILE * archPedido = fopen("pedidos.dat", "ab");

    if(archPedido!=NULL)
    {
        system("cls");
        fwrite(&p, sizeof(stPedido), 1, archPedido);
    }
    fclose(archPedido);
}

void mostrarStructPedido(stPedido p)
{
    puts("\n------------------------------------------------------------\n");
    printf("\nId Pedido: %d\n", p.idPedido);
    printf("\n\nId Cliente: %d\n", p.idCliente);
    printf("\n\nId Producto: %d\n", p.idProducto);
    puts("\n------------------------------------------------------------\n");
}


int buscaIdUltimoPedido(char rutaDelArchivoPedido[])
{
    int rta=-1;
    stPedido aux;
    FILE * archi = fopen(rutaDelArchivoPedido, "rb");
    if (archi)
    {
        while(fread(&aux, sizeof(stPedido), 1, archi)>0)
        {
            if(aux.idPedido>rta)
            {
                rta=aux.idPedido;
            }
        }
        fclose(archi);
    }
    return rta;
}
