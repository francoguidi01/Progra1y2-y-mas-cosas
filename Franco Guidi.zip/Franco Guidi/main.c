#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

typedef struct
{
    int idRegistro;
    int idPaciente;
    int idEspecialidad;
    char nombrePaciente[30];
    char apellidoPaciente[30];
    char diagnostico[100];
    char fechaAtencion[11];   /// formato: AAAA-mm-DD
    char especialidadMedica[30];
    char nombreDoctor[30];
} stRegistroMedico;


///Punto 1
///Elegi lista de listas porque no se sabe cuantas especialidades medicas hay.

typedef struct paciente
{
    char nombrePaciente[30];
    char apellidoPaciente[30];
    char diagnostico[100];
    char fechaAtencion[11];
} paciente;

typedef struct nodoPaciente
{
    paciente p;
    int idPaciente;
    struct nodoPaciente* sig;
} nodoPaciente;

typedef struct nodoEspecialidad
{
    int idRegistro;
    int idEspecialidad;
    char especialidadMedica[30];
    char nombreDoctor[30];
    nodoPaciente * pacientes;
    struct nodoEspecialidad * sig;
} nodoEspecialidad;

nodoEspecialidad * inicListaEspecialidad();
nodoPaciente * inicListaPaciente();
nodoEspecialidad * pasarDeArchivoALista (nodoEspecialidad * listaEspecialidad, char archi[]);
nodoEspecialidad * altaEspecialidad (nodoEspecialidad * listaEspecialidad, paciente persona, int idPaciente, char nombreDoctor[], int idEspecialidad, char especialidadMedica[], int idRegistro);
nodoPaciente * crearNodoPaciente(paciente persona,int idPaciente);
nodoEspecialidad * crearNodoEsp(char nombreDoctor[], int idEspecialidad, char especialidadMedica[], int idRegistro);
nodoEspecialidad * buscaPosEspecialidad(nodoEspecialidad * lista, int idEspecialidad);
nodoEspecialidad * agregarAlFinalEsp(nodoEspecialidad * listaEsp, nodoEspecialidad * espBuscada);
nodoEspecialidad * buscarUltimoNodoLDL(nodoEspecialidad * listaEsp);
nodoPaciente * agregarNodoNuevoPaciente (nodoPaciente * listaPaciente, nodoPaciente * nuevoPaciente);

///Punto 3
void recorrerYmostrarEspecialidades(nodoEspecialidad * lista);
void mostrarNodo(nodoEspecialidad * seg);
void recorrerYmostrarPacientes(nodoPaciente * lista);
void mostrarNodoPaciente(nodoPaciente * aux);
void mostrarPaciente(paciente dato);

///Punto 4
nodoEspecialidad * cargarDatosNuevos (nodoEspecialidad * listaEsp);

///Punto 5
int buscarPacienteEsp (nodoEspecialidad * listaEsp, char nombre[], char apellido []);
int buscarPacienteEnPacientes (nodoPaciente * listaPac, char nombre[], char apellido []);

///Punto 6
void recorrerYContarEspecialidades (nodoEspecialidad * listaEsp);
int recorrerYcontarPacientes (nodoPaciente * listaPac);

///Punto 7
void guardarArchiEspMedica (nodoEspecialidad * listaEsp, int idEspecialidad);

int main()
{
    printf("Hello world!\n");
    ///Punto 2
    char nombreArchi[]="registroMedico.dat";
    nodoEspecialidad * listaEsp=inicListaEspecialidad();
    listaEsp = pasarDeArchivoALista(listaEsp, nombreArchi);
    ///Punto 3
    recorrerYmostrarEspecialidades(listaEsp);
    ///Punto 4
    listaEsp=cargarDatosNuevos(listaEsp);
    /// Punto 5
    char nombre[30];
    char apellido[30];
    printf("Ingrese el nombre paciente \n");
    fflush(stdin);
    gets(nombre);

    printf("Ingrese el apellido paciente \n");
    fflush(stdin);
    gets(apellido);

    int flag=buscarPacienteEsp(listaEsp, nombre, apellido);
    printf("\n el flag es: %d", flag);
    ///Punto 6
    recorrerYContarEspecialidades(listaEsp);
    ///Punto 7
    int idEsp=0;
    printf("\ningrese el id de la especialidad a guardar ");
    scanf("%d", &idEsp);
    guardarArchiEspMedica(listaEsp, idEsp);

    return 0;
}

nodoEspecialidad * inicListaEspecialidad()
{
    return NULL;
}
nodoPaciente * inicListaPaciente()
{
    return NULL;
}


///Punto 2

nodoEspecialidad * pasarDeArchivoALista (nodoEspecialidad * listaEspecialidad, char archi[])
{
    stRegistroMedico aux;
    paciente persona;
    FILE * registro= fopen(archi,"rb");
    // nodoPaciente * listaPaciente=inicListaPaciente();
    if (registro)
    {
        while(fread(&aux,sizeof(stRegistroMedico),1,registro)>0)
        {
            strcpy(persona.nombrePaciente,aux.nombrePaciente);
            strcpy(persona.apellidoPaciente,aux.apellidoPaciente);
            strcpy(persona.diagnostico,aux.diagnostico);
            strcpy(persona.fechaAtencion,aux.fechaAtencion);
            //    strcpy(persona.nombreDoctor,aux.nombreDoctor);
            listaEspecialidad=altaEspecialidad(listaEspecialidad, persona, aux.idPaciente, aux.nombreDoctor, aux.idEspecialidad, aux.especialidadMedica, aux.idRegistro);

        }
        fclose(registro);
    }
    return listaEspecialidad;
}


nodoEspecialidad * altaEspecialidad (nodoEspecialidad * listaEspecialidad, paciente persona, int idPaciente, char nombreDoctor[], int idEspecialidad, char especialidadMedica[], int idRegistro)
{
    nodoPaciente * nuevoPaciente = crearNodoPaciente(persona, idPaciente);
    nodoEspecialidad * especialidadAbuscar= buscaPosEspecialidad(listaEspecialidad,idEspecialidad);

    if(!especialidadAbuscar)
    {
        especialidadAbuscar=crearNodoEsp(nombreDoctor, idEspecialidad, especialidadMedica, idRegistro);
        listaEspecialidad= agregarAlFinalEsp(listaEspecialidad, especialidadAbuscar);
        especialidadAbuscar=buscarUltimoNodoLDL(listaEspecialidad);
    }

    especialidadAbuscar->pacientes= agregarNodoNuevoPaciente(especialidadAbuscar->pacientes,nuevoPaciente);

    return listaEspecialidad;
}

nodoPaciente * crearNodoPaciente(paciente persona,int idPaciente)
{
    nodoPaciente * nuevoNodo = (nodoPaciente*) malloc(sizeof(nodoPaciente));
    nuevoNodo->p=persona;
    nuevoNodo->idPaciente=idPaciente;
    nuevoNodo->sig=NULL;
    return nuevoNodo;
}

nodoEspecialidad * crearNodoEsp(char nombreDoctor[], int idEspecialidad, char especialidadMedica[], int idRegistro)
{
    nodoEspecialidad * nuevoNodo = (nodoEspecialidad*) malloc(sizeof(nodoEspecialidad));
    strcpy(nuevoNodo->especialidadMedica,especialidadMedica);

    strcpy( nuevoNodo->nombreDoctor,nombreDoctor);

    nuevoNodo->idRegistro=idRegistro;

    nuevoNodo->idEspecialidad=idEspecialidad;

    nuevoNodo->sig=NULL;
    return nuevoNodo;
}

nodoEspecialidad * buscaPosEspecialidad(nodoEspecialidad * lista, int idEspecialidad)
{
    nodoEspecialidad * rta = NULL;


    if(lista)
    {
        if(idEspecialidad == lista->idEspecialidad)
        {

            rta=lista;
        }
        else
        {
            rta=buscaPosEspecialidad(lista->sig, idEspecialidad);
        }
    }

    return rta;
}

nodoEspecialidad * agregarAlFinalEsp(nodoEspecialidad * listaEsp, nodoEspecialidad * espBuscada)
{
    if(!listaEsp)
    {
        listaEsp=espBuscada;
    }
    else
    {
        if(!listaEsp->sig)
        {
            listaEsp->sig=espBuscada;
        }
        else
        {
            listaEsp->sig=agregarAlFinalEsp(listaEsp->sig, espBuscada);
        }
    }


    return listaEsp;
}

nodoEspecialidad * buscarUltimoNodoLDL(nodoEspecialidad * listaEsp)
{
    nodoEspecialidad * rta= NULL;

    if(listaEsp)
    {
        if(!listaEsp->sig)
        {
            rta=listaEsp;
        }
        else
        {
            rta=buscarUltimoNodoLDL(listaEsp->sig);
        }
    }

    return rta;
}

nodoPaciente * agregarNodoNuevoPaciente (nodoPaciente * listaPaciente, nodoPaciente * nuevoPaciente)
{
    if(listaPaciente == NULL)
    {
        listaPaciente = nuevoPaciente;
    }
    else
    {
        nuevoPaciente->sig = listaPaciente;
        listaPaciente = nuevoPaciente;
    }
    return listaPaciente;
}

///Punto 3

void recorrerYmostrarEspecialidades(nodoEspecialidad * lista)
{
    while (lista)
    {
        printf("\n-----------------------\n");
        mostrarNodo(lista);
        recorrerYmostrarPacientes(lista->pacientes);
        printf("\n-----------------------\n");
        lista= lista->sig;
    }
}

void mostrarNodo(nodoEspecialidad * lista)
{
    printf("\nId registro: %d\n", lista->idRegistro);
    printf("\nId Especialidad: %d\n", lista->idEspecialidad);
    printf("\nEspecialidad: %s\n", lista->especialidadMedica);
    printf("\nDoctor: %s\n", lista->nombreDoctor);
}

void recorrerYmostrarPacientes(nodoPaciente * lista)
{
    while (lista)
    {
        mostrarNodoPaciente(lista);
        lista = lista->sig;
    }

}

void mostrarNodoPaciente(nodoPaciente * aux)
{
    printf("\n-----------------------\n");
    printf("Id Paciente: %d \n", aux->idPaciente);
    mostrarPaciente(aux->p);
    printf("-----------------------\n");
}

void mostrarPaciente(paciente dato)
{
    printf("Nombre: %s \n", dato.nombrePaciente);
    printf("Apellido: %s \n", dato.apellidoPaciente);
    printf("Diagnostico: %s \n", dato.diagnostico);
    printf("Fecha que fue atendido: %s \n", dato.fechaAtencion);
}

///Punto 4

nodoEspecialidad * cargarDatosNuevos (nodoEspecialidad * listaEsp)
{
    stRegistroMedico aux;
    char continuar;
    paciente persona;
    do
    {

        printf("Por favor ingrese el Id paciente \n");
        scanf("%d",&aux.idPaciente);

        printf("ingrese el Id Especialidad \n");
        scanf("%d",&aux.idEspecialidad);

        printf("ingrese el Id Registro \n");
        scanf("%d",&aux.idRegistro);

        printf("Ingrese el nombre paciente \n");
        fflush(stdin);
        gets(aux.nombrePaciente);

        printf("Ingrese el apellido paciente \n");
        fflush(stdin);
        gets(aux.apellidoPaciente);

        printf("Ingrese el nombre doctor \n");
        fflush(stdin);
        gets(aux.nombreDoctor);

        printf("Ingrese el diagnostico \n");
        fflush(stdin);
        gets(aux.diagnostico);

        printf("Ingrese la fecha \n");
        fflush(stdin);
        gets(aux.fechaAtencion);
        strcpy(persona.nombrePaciente,aux.nombrePaciente);
        strcpy(persona.apellidoPaciente,aux.apellidoPaciente);
        strcpy(persona.diagnostico,aux.diagnostico);
        strcpy(persona.fechaAtencion,aux.fechaAtencion);
        listaEsp=altaEspecialidad(listaEsp, persona, aux.idPaciente, aux.nombreDoctor, aux.idEspecialidad, aux.especialidadMedica, aux.idRegistro);
        printf("Desea seguir cargando especialidades? -> s/n \n");
        continuar=getch();

    }
    while(continuar == 's');
    return listaEsp;
}

///Punto 5


int buscarPacienteEsp (nodoEspecialidad * listaEsp, char nombre[], char apellido [])
{
    int flag=0;
    while (listaEsp && flag==0)
    {
        flag=buscarPacienteEnPacientes(listaEsp->pacientes, nombre, apellido);
        listaEsp=listaEsp->sig;
    }
    return flag;
}

int buscarPacienteEnPacientes (nodoPaciente * listaPac, char nombre[], char apellido [])
{
    int flag=0;
    while (listaPac && flag==0)
    {
        if (strcmp(listaPac->p.nombrePaciente, nombre)==0 && strcmp(listaPac->p.apellidoPaciente, apellido)==0)
        {
            flag=1;
        }
        listaPac=listaPac->sig;
    }
    return flag;
}


///Punto 6


void recorrerYContarEspecialidades (nodoEspecialidad * listaEsp)
{
    int i=0;
    int rta=0;
    int idEspecialidad=listaEsp->idEspecialidad;
    char nombreEspecialidad[30];
    while (listaEsp)
    {
        i=recorrerYcontarPacientes(listaEsp->pacientes);

        if (i>=rta)
        {
            rta=i;
            idEspecialidad=listaEsp->idEspecialidad;
            strcpy(nombreEspecialidad, listaEsp->especialidadMedica);
        }

        listaEsp=listaEsp->sig;
    }
    printf("\nEsta es la especialidad con mas pacientes: \n");
    printf("\nId Especialidad: %d\n", idEspecialidad);
    printf("\nNombre especialidad: %s\n", nombreEspecialidad);
    system("pause");
}

int recorrerYcontarPacientes (nodoPaciente * listaPac)
{
    int i=0;

    while(listaPac)
    {
        listaPac=listaPac->sig;
        i++;
    }
    return i;
}

///Punto 7

void guardarArchiEspMedica (nodoEspecialidad * listaEsp, int idEspecialidad)
{
    nodoEspecialidad * aGuardar= buscaPosEspecialidad(listaEsp, idEspecialidad);
    char nombreArchi[]= "nuevoArchi.dat";
    FILE * archi1=fopen(nombreArchi, "wb");
    stRegistroMedico aux;
    if(archi1 && aGuardar)
    {

        strcpy(aux.apellidoPaciente, aGuardar->pacientes->p.apellidoPaciente);
        strcpy(aux.diagnostico, aGuardar->pacientes->p.diagnostico);
        strcpy(aux.nombrePaciente, aGuardar->pacientes->p.nombrePaciente);
        strcpy(aux.especialidadMedica, aGuardar->especialidadMedica);
        strcpy(aux.fechaAtencion, aGuardar->pacientes->p.fechaAtencion);
        strcpy(aux.nombreDoctor, aGuardar->nombreDoctor);
        aux.idEspecialidad=aGuardar->idEspecialidad;
        aux.idPaciente=aGuardar->pacientes->idPaciente;
        aux.idRegistro=aGuardar->idRegistro;
        fwrite(&aux, sizeof(stRegistroMedico), 1, archi1);
    }
}
